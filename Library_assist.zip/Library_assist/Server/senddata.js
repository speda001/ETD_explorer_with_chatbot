const fs = require('fs');
const csv = require('csv-parser');
const axios = require('axios');

async function send_data() {
    const path_name = "C:/Library_assist/Server/final_data_2.csv";
    const base_url = "http://localhost:9200";
    let success_count = 0;
    let error_count = 0;
    let success_ids = [];
    let error_details = [];

    fs.createReadStream(path_name)
      .pipe(csv())
      .on('data', async (row) => {
          try {
              let wikifier_terms = [];
              try {
                  if ("wikifier_terms" in row && row["wikifier_terms"]) {
                    //  console.log("entered wikifier_terms")
                      wikifier_terms = JSON.parse(row["wikifier_terms"]);
                      console.log("changed data",wikifier_terms);
                  }
              } catch (err) {
                  error_count++;
                  error_details.push({
                      'id': row['etd_file_id'],
                      'error': 'DataProcessingError',
                      'message': err.toString(),
                    //   'problematic_data': row["wikifier_terms"]
                  });
                  
                  return;
              }

              const file_url = settings.MEDIA_URL + row['etd_file_id'] + '.pdf';
              const json_data = {
                  "etd_file_id": row['etd_file_id'],
                  "title": row['title'],
                  "author": row['author'],
                  "year": row['year'],
                  "university": row['university'],
                  "program": row['program'],
                  "degree": row['degree'],
                  "advisor": row['advisor'],
                  "abstract": row['abstract'],
                  "pdf": row['pdf'],
                  "wikifier_terms": wikifier_terms,
                  "path": file_url,
              };

              const put_url = `${base_url}/my_test_index/json/${row['etd_file_id']}`;
              await axios.put(put_url, json_data);
            //   console,log(json_data);

              success_count++;
              success_ids.push(row['etd_file_id']);

          } catch (e) {
              console.error(`Failed to index data for ID ${row['etd_file_id']}:`, e);
              error_count++;
              error_details.push({
                  'id': row['etd_file_id'],
                  'error': 'RequestException',
                  'message': e.toString(),
                  'status_code': e.response ? e.response.status_code : 'No response',
                  'response_body': e.response ? e.response.data : 'No response'
              });
          }
      })
      .on('end', () => {
          console.log({
              "success_count": success_count,
              "error_count": error_count,
            //   "success_ids": success_ids,
            //   "error_details": error_details
          });
      });
}

send_data();