const { Client } = require('@elastic/elasticsearch');

// Connect to Elasticsearch
const client = new Client({
  node: 'http://localhost:9200',
  // If authentication is required:
  // auth: {
  //   username: 'your_username',
  //   password: 'your_password'
  // }
});

// Define the search function
async function searchIndex(indexName, searchQuery) {
  try {
    // Perform the search
    const response = await client.search({
      index: indexName,
      body: {
        query: {
          match: searchQuery
        }
      }
    });

    // Output the search results
    console.log(response.hits.hits);
  } catch (error) {
    // Handle the error
    console.error('Error during search:', error);
  }
}

// Replace 'your_index' with the name of your index and
// replace the searchQuery object with your query terms
const indexName = 'wikified_data';
const searchQuery = {
  year: '1970'
};

// Execute the search
searchIndex(indexName, searchQuery);