

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const express = require('express');
const { OpenAI } = require("openai");
const mysql = require('mysql');
const cors = require('cors');
const {check, validationResult} = require('express-validator');
const salt = 10;
const nodemailer = require("nodemailer");
const esClient = require('./esclient');
const bodyParser = require('body-parser');
const multer = require('multer');

const app = express();
app.use(cors({
    origin: ["http://localhost:3000"],
    methods: ["POST", "GET","PUT"],
    credentials: true
}));
app.use(express.json());
app.use(bodyParser.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: true })); 


const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Sampath123",
    database: "web_project"
});


//for the search page
app.post('/search', async (req, res) => {
  const { index, searchText, page = 1, pageSize = 10 } = req.body;
  const from = (page - 1) * pageSize;
  console.log(searchText)

  try {
    const response = await esClient.search({
      index,
      body: {
        query: {
          multi_match: {
            query: searchText,
             fields: ["*"],
            //fields: ["title", "abstract"],
            fuzziness: "AUTO"
          }
        },
        // suggest: {
        //   text: searchText,
        //   simple_suggest: {
        //     term: {
        //       fieldS:  ["*"], // You might need to specify the actual field you want to suggest for
        //     }
        //   }
        // // },
        // from, 
        // size: pageSize 
      }
    });
    console.log(response)
    const hits = response.body ? response.body.hits.hits : response.hits.hits;
    const total = response.body ? response.body.hits.total.value : response.hits.total.value;
    const suggestions = response.body ? response.body.suggest.simple_suggest[0].options : [];
    console.log(suggestions);
    res.json({ hits, total, page, pageSize, suggestions }); 
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({ error: error.message });
  }
});





const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads') 
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + '.pdf')
  }
});

const upload = multer({ storage: storage });

app.post('/upload', upload.single('pdf'), async (req, res) => {
  console.log('Received data:', req.body);
  console.log('Received file:', req.file);

  const pdfPath = `C:\\Library_assist\\Server\\${req.file.path.replace(/\\/g, '\\\\')}`;

  const document = {
    ...req.body,
    pdf_path: pdfPath,
    pdf: req.file ? req.file.path : null
  };
  console.log('Created document:', document);
  try {
    const esResponse = await esClient.index({
      index: 'wikified_data',
      document: document
    });

    console.log('Document indexed in Elasticsearch:', esResponse);

    res.json({ message: 'File uploaded and indexed successfully' });
  } catch (error) {
    console.error('Elasticsearch indexing error:', error);
    res.status(500).json({ message: 'Error indexing file in Elasticsearch' });
  }
});





app.get('/profile', (req, res) => {
  const email = req.query.email;

  if (!email) {
      return res.status(400).json({ message: 'Email is required' });
  }

  const sql = 'SELECT first_name, email, phone_no FROM user_details WHERE email = ?';
  db.query(sql, [email], (err, result) => {
      if (err) {
          console.error(err);
          res.status(500).json({ message: 'Database error' });
          return;
      }

      if (result.length > 0) {
          res.json(result[0]);
      } else {
          res.status(404).json({ message: 'User not found' });
      }
  });
});

// POST endpoint to update user profile
app.post('/updateprofile', (req, res) => {
  const { email, first_name, phone } = req.body;

  // Validate the input
  // Add validation as necessary

  const sql = 'UPDATE user_details SET first_name = ?, phone_no = ? WHERE email = ?';
  db.query(sql, [first_name, phone, email], (err, result) => {
      if (err) {
          console.error(err);
          return res.status(500).json({ message: 'Database error' });
      }

      if (result.affectedRows > 0) {
          res.json({ message: 'Profile updated successfully' });
      } else {
          res.status(404).json({ message: 'User not found' });
      }
  });
});



app.post('/adminlogin', [
  check('email', "Email length error").isEmail().isLength({ min: 10, max: 30 }),
  check('password', "Password length error").isLength({ min: 8, max: 20 })
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const sql = "SELECT * FROM admin_details WHERE `email` = ?";
  db.query(sql, [req.body.email], (err, data) => {
    if (err) {
      return res.status(500).json({ error: "Database error" });
    }
    if (data.length > 0) {
      bcrypt.compare(req.body.password.toString(), data[0].password, (err, response) => {
        if (err) return res.status(500).json({ error: "Password compare error" });
        if (response) {
          const name = data[0].name;
          const token = jwt.sign({ name }, "jwt-secret-key", { expiresIn: '1d' });
          // Set the token in a cookie
          res.cookie('token', token, { httpOnly: true, maxAge: 86400000 }); 

          return res.json("Success");
        } else {
          return res.status(401).json({ error: "Password not matched" });
        }
      });
    } else {
      return res.status(404).json({ error: "Email not found" });
    }
  });
});


// Admin home page server connection 
app.get('/user_details', (req, res)=> { 
    const sql = "SELECT * FROM user_details";
    db.query(sql,(err, data)=>{
        if(err) return res.json(err);
        return res.json(data);
    })
})

// Admin details page server connection 
app.get('/admin_details', (req, res)=> { 
    const sql = "SELECT * FROM admin_details";
    db.query(sql,(err, data)=>{
        if(err) return res.json(err);
        return res.json(data);
    })
})



// Adding new admin server connection
app.post('/create', (req, res) => {
  const checkExistingEmailSql = "SELECT COUNT(*) AS emailCount FROM admin_details WHERE email = ?";
  const checkExistingEmailValues = [req.body.email];

  db.query(checkExistingEmailSql, checkExistingEmailValues, (err, result) => {
      if (err) {
          console.error("Database error:", err);
          return res.status(500).json({ error: "Database error" });
      }

      // Check if an email with the same address already exists
      const emailCount = result[0].emailCount;
      if (emailCount > 0) {
          return res.status(400).json({ error: "Email already exists" });
      }

      // If the email doesn't exist, proceed with the insert
      const insertSql = "INSERT INTO admin_details (`name`, `email`, `password`, `phone`) VALUES ?";
      bcrypt.hash(req.body.password.toString(), salt, (err, hash)=>{
          if (err) return res.json({Error:"Error for hashing password"});
          const insertValues = [
            [req.body.first_name, req.body.email, hash, req.body.phone_no]
          ]
          db.query(insertSql, [insertValues], (err, data) => {
              if (err) {
                  console.error("Database error:", err);
                  return res.status(500).json({ error: "Database error" });
              }
              console.log("SQL Query:", insertSql);
              console.log("Inserted data:", data);
  
              return res.json(data);
          });
      })
  });
});

app.get('/user_details', (req, res) => {
  const sql = "SELECT * FROM user_details";
  db.query(sql, (err, data) => {
    if (err) return res.status(500).json(err);
    return res.json(data);
  });
});

// Update user auth_status
app.put('/approve/:email', (req, res) => {
  const userEmail = req.params.email;
  if (userEmail) {
    db.query('UPDATE user_details SET auth_status = 1 WHERE email = ?', [userEmail], (error) => {
      if (error) {
        console.error(error);
        return res.status(500).json({ error: 'An error occurred while updating auth_status.' });
      }
      return res.status(200).json({ message: 'Auth status updated successfully for ' + userEmail });
    });
  } else {
    return res.status(403).json({ error: 'Unauthorized action.' });
  }
});



//User Signup
app.post('/signup', (req, res) => {
    const checkExistingEmailSql = "SELECT COUNT(*) AS emailCount FROM user_details WHERE email = ?";
    const checkExistingEmailValues = [req.body.email];

    db.query(checkExistingEmailSql, checkExistingEmailValues, (err, result) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ error: "Database error" });
        }

        // Check if an email with the same address already exists
        const emailCount = result[0].emailCount;
        if (emailCount > 0) {
            return res.status(400).json({ error: "Email already exists" });
        }

        // If the email doesn't exist, proceed with the insert
        const insertSql = "INSERT INTO user_details (`first_name`, `last_name`, `email`, `password`, `phone_no`) VALUES ?";
        bcrypt.hash(req.body.password.toString(), salt, (err, hash)=>{
            if (err) return res.json({Error:"Error for hashing password"});
            const insertValues = [
                [req.body.first_name, req.body.last_name, req.body.email, hash, req.body.phone_no]
            ]
            db.query(insertSql, [insertValues], (err, data) => {
                if (err) {
                    console.error("Database error:", err);
                    return res.status(500).json({ error: "Database error" });
                }
                console.log("SQL Query:", insertSql);
                console.log("Inserted data:", data);
    
                return res.json(data);
            });
        })
    });
});


const transporter = nodemailer.createTransport({
  service: 'gmail', 
  auth: {
    user: 'digilibassist@gmail.com', 
    pass: 'ksay yxcp emos axzb', 
  },
});


//Forgot password
app.post('/forgotpassword', [
  check('email', "Email length error").isEmail().isLength({ min: 10, max: 30 })
], (req, res) => {
  const sql = "SELECT * FROM user_details WHERE email=?";

  db.query(sql, [req.body.email], (err, data) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.json(errors);
    } else {
      if (err) {
        return res.status(500).json({ error: "Database error" });
      }
      if (data.length > 0) {

        const resetToken = 'your-random-token'; // Ensure this token is securely generated and unique

        // Update this URL with the actual link to your password reset page
        const resetLink = `http://localhost:3000/resetpassword`;

        const mailOptions = {
          from: 'digilibassist@gmail.com',
          to: req.body.email,
          subject: 'Password Reset',
          html: `
            <p>You are receiving this because you (or someone else) have requested the reset of the password for your account.</p>
            <p>Please click on the following link or paste this into your browser to complete the process:</p>
            <a href="${resetLink}">Click Here</a>
            <p>If you did not request this, please ignore this email and your password will remain unchanged.</p>`
        };

        transporter.sendMail(mailOptions, (emailErr) => {
          if (emailErr) {
            return res.status(500).json({ error: "Email sending error" });
          }

          return res.json("Success");
        });

      } else {
        return res.json("Fail");
      }
    }
  });
});





// Change password for admin user
app.post('/changepwd', (req, res) => {
    const { email, password, npassword } = req.body;
  
    // You should implement proper authentication here to ensure the user is authorized to change the password.
  
    // First, check if the current password matches the one in the database
    db.query(
      'SELECT * FROM admin_details WHERE email = ?',
      [email], 
      (err, results) => {
        if (err) {
          res.status(500).json({ message: 'Database error' });
          return;
        }
  
        if (results.length === 0) {
          res.status(404).json({ message: 'User not found' });
          return;
        }
  
        const user = results[0];
  
        // Compare the current password with the one in the database
        if (user.password === password) {
          // Update the password in the database
          db.query(
            'UPDATE admin_details SET password = ? WHERE email = ?', // Update based on email
            [npassword, email], // Set the new password and use the email
            (err, results) => {
              if (err) {
                res.status(500).json({ message: 'Database error' });
                return;
              }
  
              res.status(200).json({ message: 'Password updated successfully' });
            }
          );
        } else {
          res.status(400).json({ message: 'Current password is incorrect' });
        }
      }
    );
  });
  



  
  app.post('/uchangepwd', (req, res) => {
    const { email, password, npassword } = req.body;
  
    // Validate the new password strength here if necessary
  
    db.query('SELECT * FROM user_details WHERE email = ?', [email], (err, results) => {
      if (err) {
        console.error(err); // Log the error for debugging purposes
        res.status(500).json({ message: 'Database error' });
        return;
      }
  
      if (results.length === 0) {
        res.status(404).json({ message: 'User not found' });
        return;
      }
  
      const user = results[0];
  
      bcrypt.compare(password, user.password, (err, isMatch) => {
        if (err) {
          console.error(err); // Log the error for debugging purposes
          res.status(500).json({ message: 'Error while checking password' });
          return;
        }
  
        if (!isMatch) {
          res.status(400).json({ message: 'Current password is incorrect' });
          return;
        }
  
        bcrypt.hash(npassword, salt, (err, hashedPassword) => {
          if (err) {
            console.error(err); // Log the error for debugging purposes
            res.status(500).json({ message: 'Error while hashing new password' });
            return;
          }
  
          db.query('UPDATE user_details SET password = ? WHERE email = ?', [hashedPassword, email], (err, results) => {
            if (err) {
              console.error(err); // Log the error for debugging purposes
              res.status(500).json({ message: 'Database error during password update' });
              return;
            }
  
            res.status(200).json({ message: 'Password updated successfully' });
          });
        });
      });
    });
  });
  


  // Function to generate a random 6-digit number
function generateRandomNumber() {
  return Math.floor(100000 + Math.random() * 900000);
}

function generateRandomAlphanumericKey(length) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}


  // Your login route with email sending
  app.post('/login', [
    check('email', "Email length error").isEmail().isLength({ min: 10, max: 30 }),
    check('password', "Password length error").isLength({ min: 8, max: 20 })
  ], (req, res, next) => {
    const sql = "SELECT * FROM user_details WHERE `email` = ? ";
  
    db.query(sql, [req.body.email], (err, data) => {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.json(errors);
      } else {
        if (err) {
          return res.status(500).json({ error: "Database error" });
        }
        if (data.length > 0) {
          if (data[0].auth_status === 0 || data[0].auth_status === null) {
            return res.status(404).json({ error: "user not authorized" });
          }
          bcrypt.compare(req.body.password.toString(), data[0].password, (err, response) => {
            if (err) return res.json({ Error: "Password compare error" });
            if (data[0].auth_status === 0 || data[0].auth_status === null) {
              return res.status(404).json({ error: "user not authorized" });
            }
            if (response) {
              const name = data[0].name;
              const token = jwt.sign({ name }, "jwt-secret-key", { expiresIn: '1d' });
  
              // Store the email and verificationCode in the request object
              req.email = req.body.email;
              const verificationCode = generateRandomNumber();
              req.verificationCode = verificationCode;

              
  
              const mailOptions = {
                from: 'digilibassist@gmail.com',
                to: req.body.email,
                subject: 'Login Verification Code',
                text: `Your verification code is: ${verificationCode}\n\nUse this code to complete your login.`,
              };
  
              transporter.sendMail(mailOptions, (emailErr) => {
                if (emailErr) {
                  return res.status(500).json({ error: "Email sending error" });
                }
  
                
              });


              return res.json({msg:"Success",verificationCode:verificationCode});
            } else {
              return res.json({ Error: "Password not matched" });
            }
          });
        } else {
          return res.json("Fail");
        }
      }
    });
  });
  
  app.post('/verify-otp', [
    check('otp', 'Invalid OTP').isNumeric().isLength({ min: 6, max: 6 }),
  ], (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
  
    const { otp } = req.body;
    const { email, verificationCode } = req.body; 
    // console.log(otp,email,verificationCode)

    const key = generateRandomAlphanumericKey(10);
    req.key = key;

    if (otp === verificationCode && email) {
      return res.status(200).json({ message: 'Success',key:key });
    } else {
      return res.status(400).json({ message: 'Invalid OTP or email' });
    }
  });
  


  app.post('/searchkey', async (req, res) => {
    // Extract the apiKey and combined terms from the request body
    const { apiKey, terms, page = 1, pageSize = 10 } = req.body;

    // Check if the API key matches
    if (apiKey !== 'YourExpectedApiKey') {
      return res.status(403).json({ error: 'Invalid API key' });
    }

    // Split the combined terms into two separate terms
    const [term1, term2] = terms.split('+');
  
    // Construct the search text from the provided terms
    const searchText = `${term1} ${term2}`;
    const from = (page - 1) * pageSize;
    console.log('Search Text:', searchText);
  
    try {
      const response = await esClient.search({
        index: 'your_index_name', // Replace with your index name
        body: {
          query: {
            multi_match: {
              query: searchText,
              fields: ["*"],
              fuzziness: "AUTO"
            }
          },
          from, 
          size: pageSize 
        }
      });
  
      console.log('Response:', response);
      const hits = response.body.hits.hits;
      const total = response.body.hits.total.value;
      res.json({ hits, total, page, pageSize }); 
    } catch (error) {
      console.error('Search error:', error);
      res.status(500).json({ error: error.message });
    }
});


//Chatbot 



const openaiApiKey = "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";


// // Import the OpenAI package
// // const OpenAI = require('openai');
// app.post('/respondToQuery', async (req, res) => {
//   const user_question = req.body.message;
//   // const etd_file_id = req.body.etd_file_id; // Uncomment if needed
//   console.log("entered OpenAI")

//   if (!user_question) {
//     return res.status(400).json({'error': 'Question is required'});
//   }

//   try {
//     // Simulate fetching the current abstract (you'll need to implement this part)
   

//     const abstract = req.body.abstract;
//     const title = req.body.title;

//     const prompt = `Read the abstract of this thesis titled ${title}: ${abstract}. Answer the following questions from the reader. Question: ${user_question}`;
    
//     try {
//       const response = await openai.ChatCompletion.create({
//         model: "gpt-4-0314",
//         messages: [
//           {"role": "system", "content": "You are a helpful assistant."},
//           {"role": "user", "content": prompt}
//         ],
//         max_tokens: 50,
//         n: 1,
//         stop: null,
//         temperature: 0.7
//       });

//       const model_response = response.data.choices[0].message.content.trim();
//       return res.json({ 'model_response': model_response });
//     } catch (e) {
//       console.error('Error in OpenAI response:', e);
//       return res.status(500).json({'error': e.message});
//     }
//   } catch (e) {
//     console.error('Error:', e);
//     return res.status(500).json({'error': 'An error occurred'});
//   }
// });


// const express = require('express');
// const app = express();
// app.use(express.json());

// Import the OpenAI package
// const { OpenAIApi, Configuration } = require('openai');


// Initialize the OpenAI instance with your API key
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || "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",
});
// const openai = new OpenAIApi(configuration);

app.post('/respondToQuery', async (req, res) => {
  const user_question = req.body.message;
  const abstract = req.body.abstract;
  const title = req.body.title;
  const year = req.body.year;
  const advisor = req.body.advisor;

  console.log("Entered OpenAI");

  if (!user_question) {
    return res.status(400).json({'error': 'Question is required'});
  }

  try {
    const prompt =  `Based on the abstract of the thesis titled '${title}': ${abstract} published in year ${year} and the advisor is ${advisor}, provide a brief explanation. The inquiry is about: ${user_question}`;


    try {
      
      const completion = await openai.completions.create({
        model: "text-davinci-003",
        prompt: prompt,
        max_tokens: 30,
      });
      console.log(completion.choices[0].text);
      
      const model_response = completion.choices[0].text.trim();
      console.log("the model response is",model_response);
      return res.json({ 'model_response': model_response });
    } catch (e) {
      console.error('Error in OpenAI response:', e);
      return res.status(500).json({'error': e.message});
    }
  } catch (e) {
    console.error('Error:', e);
    return res.status(500).json({'error': 'An error occurred'});
  }
});

// Add your server listening code here

// // Example usage
// async function main() {
//   const prompt = "Translate the following English text to French: 'Hello, how are you?'";
//   const response = await getGPTResponse(prompt);
//   console.log('GPT Response:', response);
// }

// // Call the main function
// main();

// app.get('/send-data', async (req, res) => {
//   try {
//     await send_data();
//     res.send('Data sent successfully');
//   } catch (e) {
//     res.status(500).send('Error occurred: ' + e.message);
//   }
// });

app.listen(8081, () => {
    console.log("Listening on port 8081");
});
