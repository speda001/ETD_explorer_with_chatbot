// esClient.js
const { Client } = require('@elastic/elasticsearch');

// Configuration for the Elasticsearch client
const config = {
  node: 'http://localhost:9200',
  // If authentication is required:
  // auth: {
  //   username: 'your_username',
  //   password: 'your_password'
  // }
};

// Create a single instance of the Elasticsearch client
const client = new Client(config);

// Export the client
module.exports = client;