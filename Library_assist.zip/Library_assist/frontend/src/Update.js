import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

function Update() {
    const [formData, setFormData] = useState({
        title: '',
        author: '',
        year: '',
        university: '',
        program: '',
        degree: '',
        advisor: '',
        abstract: '',
        pdf: null,
        wikifier_terms: '' 
    });
    const handleLogout = () => {
        navigate('/login');
      };
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();
    const [backendError, setBackendError] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [fileInputKey, setFileInputKey] = useState(Date.now());

    const validate = () => {
        let tempErrors = {};
        tempErrors.title = formData.title ? '' : 'Title is required.';
        tempErrors.author = formData.author ? '' : 'Author is required.';
        tempErrors.year = formData.year ? '' : 'Year is required.';
        tempErrors.university = formData.university ? '' : 'University is required.';
        tempErrors.program = formData.program ? '' : 'Program is required.';
        tempErrors.degree = formData.degree ? '' : 'Degree is required.';
        tempErrors.advisor = formData.advisor ? '' : 'Advisor is required.';
        tempErrors.abstract = formData.abstract ? '' : 'Abstract is required.';
        tempErrors.wikifier_terms = formData.wikifier_terms ? '' : 'Wikifier terms are required.';

        if (formData.pdf) {
            tempErrors.pdf = formData.pdf.name.endsWith('.pdf') ? '' : 'Only PDF files are allowed.';
        } else {
            tempErrors.pdf = 'PDF file is required.';
        }

        setErrors(tempErrors);
        return Object.values(tempErrors).every(x => x === '');
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleFileChange = (e) => {
        setFormData({
            ...formData,
            pdf: e.target.files[0]
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setBackendError('');
        setSuccessMessage('');

        // Generate a random number for etd_file_id
        const etdFileId = 502 + Math.floor(Math.random() * 10000);
        formData.etd_file_id = etdFileId.toString();

        if (!validate()) return;

        const dataToSend = new FormData();
        Object.entries(formData).forEach(([key, value]) => {
            dataToSend.append(key, value);
        });

        try {
            const response = await axios.post('http://localhost:8081/upload', dataToSend);

            if (response.data.error_details && response.data.error_details.length > 0) {
                const firstError = response.data.error_details[0];
                setBackendError(firstError.message);
            } else {
                setSuccessMessage("File uploaded successfully.");
                setFormData({
                    title: '',
                    author: '',
                    year: '',
                    university: '',
                    program: '',
                    degree: '',
                    advisor: '',
                    abstract: '',
                    pdf: null,
                    wikifier_terms: '' 
                });
                setFileInputKey(Date.now());
                alert('File upload completed successfully');
                navigate('/user_home');
                setTimeout(() => {
                    setSuccessMessage('');
                }, 5000);
            }
        } catch (error) {
            console.error('Error:', error.message);
            setBackendError("An error occurred while making the request. Please try again.");
        }
    };

    return (
        <div>
            <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <Link className="navbar-brand px-2" to="/user_home">Home</Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link px-2" to="/user_profile">Profile</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link px-2" to="/changepassword">Change Password</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link px-2" to="/upload">Upload Doc</Link>
              </li>
            </ul>
          </div>
          <button
            className="btn btn-outline-danger p-2"
            onClick={handleLogout}>
            Logout
          </button>
        </div>
      </nav>
            </div>
            <div>
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
            <form onSubmit={handleSubmit} style={{ textAlign: 'center', width: '100%' }}>
                {Object.entries(formData).map(([key, value]) => {
                    if (key !== 'pdf' && key !== 'etd_file_id') {
                        return (
                            <div className="form-row" key={key} style={{ marginBottom: '10px' }}>
                                <label>{key.charAt(0).toUpperCase() + key.slice(1)}:</label>
                                <input
                                    type="text"
                                    name={key}
                                    value={value}
                                    onChange={handleChange}
                                    className={errors[key] ? 'input-error' : ''}
                                    style={{ marginLeft: '10px' }}
                                />
                                {errors[key] && <div className="error">{errors[key]}</div>}
                            </div>
                        );
                    }
                    return null;
                })}
                <div className="form-row" style={{ marginBottom: '10px' }}>
                    <label>PDF:</label>
                    <input
                        key={fileInputKey}
                        type="file"
                        name="pdf"
                        onChange={handleFileChange}
                        className={errors.pdf ? 'input-error' : ''}
                        style={{ marginLeft: '10px' }}
                    />
                    {errors.pdf && <div className="error">{errors.pdf}</div>}
                </div>
                {backendError && <div className="backend-error">{backendError}</div>}
                {successMessage && <div className="success-message">{successMessage}</div>}
                <button type="submit" className="submit-button" style={{ marginTop: '20px' }}>Submit</button>
            </form>
        </div>
            </div>
        </div>
        
    );
}

export default Update;
