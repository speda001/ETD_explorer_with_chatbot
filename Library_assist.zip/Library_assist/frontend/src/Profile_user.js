import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

function Profile_user() {
    const navigate = useNavigate();
    const [profile, setProfile] = useState({ first_name: '', email: '', phone: '' });

    // State for the form fields
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');

    useEffect(() => {
        const fetchProfile = async () => {
            const userEmail = 'speda001@odu.edu';

            try {
                const response = await axios.get('http://localhost:8081/profile', {
                    params: { email: userEmail }
                });
                setProfile(response.data);
                setName(response.data.first_name);
                setPhone(response.data.phone_no);
            } catch (error) {
                console.error('Error fetching profile data:', error);
            }
        };

        fetchProfile();
    }, []);

    const handleUpdate = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:8081/updateprofile', {
                email: 'speda001@odu.edu',
                first_name: name,
                phone: phone
            });
            alert('Profile updated successfully');
        } catch (error) {
            console.error('Error updating profile:', error);
            alert('Error in updating profile');
        }
    };

    const handleLogout = () => {
        navigate('/login');
    };

    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <Link className="navbar-brand px-2" to="/user_home">Home</Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link px-2" to="/user_profile">Profile</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link px-2" to="/changepassword">Change Password</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link px-2" to="/upload">Upload Doc</Link>
              </li>
            </ul>
          </div>
          <button
            className="btn btn-outline-danger p-2"
            onClick={handleLogout}>
            Logout
          </button>
        </div>
      </nav>
            <div className='d-flex justify-content-center align-items-center bg-secondary vh-100'>
                <div className='bg-white p-5 rounded'>
                    <h2>Profile Details</h2>
                    <form onSubmit={handleUpdate}>
                    <label>Email:</label>
                        <div><h6>{profile.email}</h6></div>
                        <div className='mb-3'>
                            <label>First Name:</label>
                            <input
                                type='text'
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className='form-control'
                            />
                        </div>
                        
                        <div className='mb-3'>
                            <label>Phone:</label>
                            <input
                                type='text'
                                value={phone}
                                onChange={(e) => setPhone(e.target.value)}
                                className='form-control'
                            />
                        </div>
                        <button type="submit" className='btn btn-success'>Update Profile</button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default Profile_user;
