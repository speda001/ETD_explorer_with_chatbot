const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'digilibassist@gmail.com',
    pass: 'krmi temo zciw lczg'
  }
});

const mailOptions = {
  from: 'hello@example.com',
  to: '',
  subject: 'One time Password',
  text: ''
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
 console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
    // do something useful
  }
});