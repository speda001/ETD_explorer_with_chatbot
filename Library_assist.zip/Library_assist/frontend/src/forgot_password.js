import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Validation from './LoginValidation';
import axios from 'axios';

function ForgotPassword() {
  const [values, setValues] = useState({
    email: '',
  });
  const navigate = useNavigate();
  const [errors, setErrors] = useState({});
  const [backendError, setBackendError] = useState('');

  const handleInput = (event) => {
    setValues((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setErrors(Validation(values));
    if (errors.email === '') {
      axios.post('http://localhost:8081/forgotpassword', values)
        .then((res) => {
          if (res.data.errors) {
            setBackendError(res.data.errors[0].msg);
          } else {
            setBackendError('');
            if (res.data === 'Success') {
              navigate('/login');
            } else {
              alert('No record existed');
            }
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };

  return (
    <div className='d-flex justify-content-center align-items-center bg-secondary vh-100'>
      <div className='bg-white p-3 rounded w-25'>
        <h2>Login</h2>
        {backendError && (
          <p className='text-danger'>{backendError}</p>
        )}
        <form action='' onSubmit={handleSubmit}>
          <div className='mb-3'>
            <label htmlFor='email'><strong>Email</strong></label>
            <input
              type='email'
              placeholder='Enter email'
              name='email'
              onChange={handleInput}
              className='form-control rounded'
            />
            {errors.email && <span className='text-danger'>{errors.email}</span>}
          </div>
          <button type='submit' className='btn btn-success w-100 rounded-0'>
            Send Email
          </button>
          <p></p>
        </form>
      </div>
    </div>
  );
}

export default ForgotPassword;
