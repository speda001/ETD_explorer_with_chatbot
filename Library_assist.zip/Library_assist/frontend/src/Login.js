import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import ReCAPTCHA from 'react-google-recaptcha';
import Cookies from 'js-cookie';

function Login() {
    const navigate = useNavigate();
    const [values, setValues] = useState({ email: '', password: '' });
    const [errors, setErrors] = useState({});
    const [recaptchaToken, setRecaptchaToken] = useState('');
    const [recaptchaVerified, setRecaptchaVerified] = useState(false);
    const [backendError, setBackendError] = useState([]);
    const [alertMessage, setAlertMessage] = useState('');

    const handleInput = (event) => {
        setValues({ ...values, [event.target.name]: event.target.value });
    };

    const handleRecaptcha = (token) => {
        setRecaptchaToken(token);
        setRecaptchaVerified(!!token);
    };

    const validateInputs = () => {
        const newErrors = {};
        if (!values.email) {
            newErrors.email = 'Email is required';
        }
        if (!values.password) {
            newErrors.password = 'Password is required';
        }
        if (!recaptchaVerified) {
            newErrors.recaptcha = 'Please verify you are not a robot';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        if (validateInputs()) {
            axios.post('http://localhost:8081/login', values)
                .then((res) => {
                    if (res.data.msg === 'Success') {
                        sessionStorage.setItem('verificationCode', res.data.verificationCode);
                        sessionStorage.setItem('email', values.email);
                        navigate('/otp');
                        Cookies.set('token', res.headers['x-auth-token']);
                    } else {
                        alert('No record existed');
                    }
                })
                .catch((err) => {
                    if (err.response && err.response.status === 404 && err.response.data.error === 'user not authorized') {
                        setAlertMessage('Thanks for Signing up with us. We are waiting for admin to authorize your account');
                    } else {
                        console.error(err);
                    }
                });
        }
    };

    return (
        <div className='d-flex justify-content-center align-items-center bg-secondary vh-100'>
            <div className='bg-white p-3 rounded w-25'>
                <h2>Login</h2>
                {backendError && backendError.map((e, index) => <p key={index} className='text-danger'>{e.msg}</p>)}
                {alertMessage && (
                    <div className="alert alert-warning" role="alert">
                        {alertMessage}
                    </div>
                )}
                <form onSubmit={handleSubmit}>
                    <div className='mb-3'>
                        <label htmlFor='email'><strong>Email</strong></label>
                        <input
                            type='email'
                            placeholder='Enter email'
                            name='email'
                            value={values.email}
                            onChange={handleInput}
                            className='form-control rounded'
                        />
                        {errors.email && <span className='text-danger'>{errors.email}</span>}
                    </div>
                    <div className='mb-3'>
                        <label htmlFor='password'><strong>Password</strong></label>
                        <input
                            type='password'
                            placeholder='Enter password'
                            name='password'
                            value={values.password}
                            onChange={handleInput}
                            className='form-control rounded'
                        />
                        {errors.password && <span className='text-danger'>{errors.password}</span>}
                    </div>
                    <ReCAPTCHA
                        sitekey="6LdOXSIpAAAAAF8rU6RwCyvY-qT2_7WL5k4hsbiv"
                        onChange={handleRecaptcha}
                        className="mb-3"
                    />
                    {errors.recaptcha && <span className='text-danger'>{errors.recaptcha}</span>}
                    <button type='submit' className='btn btn-success w-100 rounded-0'>
                        Login
                    </button>
                    <Link
                        to='/signup'
                        className='btn btn-default border w-100 bg-light rounded-0 mt-2 text-decoration-none'
                    >
                        Create Account
                    </Link>
                </form>
                <div className='forgot-password align-items-center'>
                    <a href='/forgot_password'>Forgot Password?</a>
                </div>
            </div>
        </div>
    );
}

export default Login;
