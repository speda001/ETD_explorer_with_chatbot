import React, {useEffect, useState} from 'react'
import { useNavigate, Link} from 'react-router-dom'
import axios from 'axios'; 

function Admin_details() {

    const[data,setData]=useState([]);
    useEffect(()=>{
        axios.get('http://localhost:8081/admin_details')
        .then(res=>setData(res.data))
        .catch(err=> console.log(err));
    })

  return (
    <div >
        <nav className="navbar navbar-expand-lg navbar-light bg-light p-3">
                <div className="container-fluid">
                <button className="btn btn-outline-secondary me-2">Back</button>
                <Link className="navbar-brand" to="/admin">
                    Home
                </Link>
                <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav">
                    <li className="nav-item">
                        <Link to="/create_admin" className="nav-link btn btn-outline-success mx-2">
                        Add Admin
                        </Link>
                    </li>
                    <li className="nav-item">
                        <Link to="/admin_details" className="nav-link btn btn-outline-info">
                        Admin Details
                        </Link>
                    </li>
                    <li className="nav-item">
                        <Link
                        className="nav-link  btn btn-outline-secondary"
                        to="/admin_changepassword"
                        >
                        Change Password
                        </Link>
                    </li>
                    </ul>
                </div>
                </div>
            </nav>

        <div className='d-flex justify-content-center bg-secondary align-items-center vh-100'>
            <div className='bg-white rounded w-45 p-4 '>
            <h4>Existing Admins</h4>
            <table className='table'>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((d,i)=>(
                        <tr>
                            <td>{d.name}</td>
                            <td>{d.phone}</td>
                            <td>{d.email}</td>
                            

                            
                        </tr>
                    ))}
                </tbody>
            </table>
        </div></div>
        

    </div>
  )
}

export default Admin_details