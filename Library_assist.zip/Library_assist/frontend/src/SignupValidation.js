function Validation(values){
    let error ={}
    const email_pattern= /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    const password_pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-z0-9]{8,}$/
    // const phone_pattern = /^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$/
  

    if(values.email === ""){
        error.email = "Email Should not be empty"
    }
    else if(!email_pattern.test(values.email)){
        error.email="Email didn't match"
    }else{
        error.email = ""
    }


    if(values.password === ""){
        error.password = "Password Should not be empty"
    }
    else if(!password_pattern.test(values.password)){
        error.password = "Password didn't match"
    } else {
        error.password = ""
    }

    if(values.first_name === ""){
        error.first_name = "First Name Should not be empty"
    }
    else{
        error.first_name = ""
    }


    if(values.last_name === ""){
        error.last_name = "Last Name Should not be empty"
    }
    else{
        error.last_name = ""
    }


    if(values.phone_no === ""){
        error.phone_no = "Phone Number Should not be empty"
    }
     else {
        error.phone_no = ""
    }
    return error;


    


}

export default Validation;
