import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

function User_changepassword() {
  const [password, setPassword] = useState('');
  const [npassword, setnPassword] = useState('');

  const navigate = useNavigate();

  const handleLogout = () => {
    navigate('/login');
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const email = 'speda001@odu.edu';  // Hardcoded email address

    axios
      .post('http://localhost:8081/uchangepwd', { email, password, npassword })
      .then((res) => {
        if (res.status === 200) {
          console.log('Password updated successfully');
          navigate('/user_home');
          alert('Password updated successfully');
        } else {
          console.error('Failed to update password');
        }
      })
      .catch((err) => {
        console.error('Error updating password:', err);
        alert('Error in updating password');
      });
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <Link className="navbar-brand px-2" to="/user_home">Home</Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link px-2" to="/user_profile">Profile</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link px-2" to="/changepassword">Change Password</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link px-2" to="/upload">Upload Doc</Link>
              </li>
            </ul>
          </div>
          <button
            className="btn btn-outline-danger p-2"
            onClick={handleLogout}>
            Logout
          </button>
        </div>
      </nav>
      <div className='d-flex justify-content-center align-items-center bg-secondary vh-100'>
        <div className='bg-white p-5 rounded w-25'>
          <h3>Change Password</h3>
          <form onSubmit={handleSubmit}>
            <div className='mb-2'>
              <label>Current Password</label>
              <input
                type='password'
                name='password'
                placeholder='Enter Your current password'
                className='form-control'
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div className='mb-2'>
              <label>New Password</label>
              <input
                type='password'
                name='npassword'
                placeholder='Enter New Password'
                className='form-control'
                onChange={(e) => setnPassword(e.target.value)}
              />
            </div>
            <button className='btn btn-success'>Submit</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default User_changepassword;
