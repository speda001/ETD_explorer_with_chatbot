import React, { useState, useEffect } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import DOMPurify from 'dompurify';

function Home() {
  const location = useLocation();
  const navigate = useNavigate();
  const key = sessionStorage.getItem('key');
  const [searchQuery, setSearchQuery] = useState(
    localStorage.getItem('searchQuery') || location.state?.searchQuery || ''
  );
  const [currentPage, setCurrentPage] = useState(
    parseInt(localStorage.getItem('currentPage'), 10) || location.state?.currentPage || 1
  );
  const [searchResults, setSearchResults] = useState([]);
  const [totalResults, setTotalResults] = useState(0);
  const [resultsPerPage] = useState(10);
  const [suggestions, setSuggestions] = useState([]);
  const [apiKey, setApiKey] = useState(sessionStorage.getItem('key') || '');

  useEffect(() => {

    localStorage.setItem('searchQuery', searchQuery);
    localStorage.setItem('currentPage', currentPage.toString());
  }, [searchQuery, currentPage]);


  useEffect(() => {
    setApiKey(sessionStorage.getItem('key') || '');

    if (searchQuery) {
      handleSearch(searchQuery, currentPage);
    }
  }, [searchQuery, currentPage]);

  const handleSearch = (value, page) => {
    var requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        index: 'wikified_data',
        searchText: value,
        page: page,
        pageSize: resultsPerPage
      }),
      redirect: 'follow'
    };

    fetch('http://localhost:8081/search', requestOptions)
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(({ hits, total, suggestions }) => {
        setSearchResults(hits.map(hit => hit._source)); 
        setTotalResults(total); 
        setSuggestions(suggestions.map(suggestion => suggestion.text)); 
        setCurrentPage(page);
      })
      .catch(error => {
        console.error('Search error:', error);
      });
  };

  const extractScriptContent = (input) => {
    const scriptTagContent = input.match(/<script.*?>(.*?)<\/script>/i);
    return scriptTagContent ? scriptTagContent[1] : input;
  };

  // Handle change in the search input
  const handleInputChange = (e) => {
    const extractedContent = extractScriptContent(e.target.value);
    setSearchQuery(extractedContent);
    setCurrentPage(1);
  };

  const highlightSearchTerm = (text, term, charLimit = 150) => {
    if (!text) return '';
    let truncatedText = text.length > charLimit ? text.substring(0, charLimit) + '...' : text;
    if (!term) return truncatedText;
    const re = new RegExp(term, 'gi');
    const sanitizedText = DOMPurify.sanitize(truncatedText);
    return sanitizedText.replace(re, (match) => `<mark>${match}</mark>`);
  };

  const handleMoreDetails = (result) => {
    navigate('/details', { state: { data: result, searchState: { searchQuery, currentPage } } });
  };

  const handlePageClick = (pageNumber) => {
    setCurrentPage(pageNumber);
    handleSearch(searchQuery, pageNumber);
  };
  const handleLogout = () => {
    navigate('/login');
  };

  const renderPagination = () => {
    const totalPages = Math.ceil(totalResults / resultsPerPage);

    if (totalPages <= 1) {
      return (
        <>
          <button key="first" disabled>&lt;&lt;</button>
          <button key="prev" disabled>&lt;</button>
          <button key="1" className="active">1</button>
          <button key="next" disabled>&gt;</button>
          <button key="last" disabled>&gt;&gt;</button>
        </>
      );
    }
    
    let startPage, endPage;

    if (totalPages <= 3) {
      startPage = 1;
      endPage = totalPages;
    } else {
      if (currentPage <= 2) {
        startPage = 1;
        endPage = 3;
      } else if (currentPage + 1 >= totalPages) {
        startPage = totalPages - 2;
        endPage = totalPages;
      } else {
        startPage = currentPage - 1;
        endPage = currentPage + 1;
      }
    }


    const pageNumbers = [];

    pageNumbers.push(
      <button key="first" onClick={() => handlePageClick(1)} disabled={currentPage === 1}>&lt;&lt;</button>,
      <button key="prev" onClick={() => handlePageClick(Math.max(1, currentPage - 1))} disabled={currentPage === 1}>&lt;</button>
    );

    for (let page = startPage; page <= endPage; page++) {
      pageNumbers.push(
        <button key={page} onClick={() => handlePageClick(page)} className={currentPage === page ? 'active' : ''}>
          {page}
        </button>
      );
    }

    pageNumbers.push(
      <button key="next" onClick={() => handlePageClick(Math.min(totalPages, currentPage + 1))} disabled={currentPage === totalPages}>&gt;</button>,
      <button key="last" onClick={() => handlePageClick(totalPages)} disabled={currentPage === totalPages}>&gt;&gt;</button>
    );

    return pageNumbers;
  };

  const renderSuggestions = () => {
    if (suggestions.length === 0) return null;

    return (
      <ul className="suggestions-list">
        {suggestions.map((suggestion, index) => (
          <li key={index} onClick={() => { setSearchQuery(suggestion); handleSearch(suggestion, 1); }}>
            {suggestion}
          </li>
        ))}
      </ul>
    );
  };

  return (
    <div>
      <div className="bg-light" id="navbarNav">
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <div className="container-fluid">
            <Link className="navbar-brand px-2" to="/user_home">
              Home
            </Link>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link px-2" to="/user_profile">
                    Profile
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link px-2" to="/changepassword">
                    Change Password
                  </Link>
                </li>
                <li className="nav-item">
                <Link className="nav-link px-2" to="/upload">Upload Doc</Link>
              </li>
              </ul>
            </div>
            
            <div className="input-group align-items-left w-50 search-container">
              <input
                onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                value={searchQuery}
                type="text"
                className="form-control"
                placeholder="Search..."
              />
              <button onClick={() => handleSearch(searchQuery, 1)} className="btn btn-outline-secondary">Search</button>
            </div>
            <button
                  className="btn btn-outline-danger p-2"
                  onClick={handleLogout}>
                  Logout
                </button>
          </div>
        </nav>

      </div>

      <div className="search-container">
      <label>API Key: {apiKey}</label><br></br>
        <label>Showing search results for: <strong>{searchQuery}</strong></label>
        <br></br>
        {suggestions.length > 0 && (
          <div>
            <label>Suggestions: </label>
            {renderSuggestions()}
          </div>
        )}
        <label>Total Results: {totalResults}</label>
        {searchResults.map((result, index) => (
          <div key={index} className="search-result">
            <h3 dangerouslySetInnerHTML={{ __html: highlightSearchTerm(result.title, searchQuery) }}></h3>
            <p dangerouslySetInnerHTML={{ __html: highlightSearchTerm(result.abstract, searchQuery) }}></p>
            <p>Author: {result.author}</p>
            <button onClick={() => handleMoreDetails(result)} className="btn btn-primary">More Details</button>
          </div>
        ))}

        {totalResults > resultsPerPage && (
          <div className="pagination" style={{ display: 'flex', justifyContent: 'center' }}>
            {renderPagination()}
          </div>
        )}
      </div>
    </div>
  );
}

export default Home;
