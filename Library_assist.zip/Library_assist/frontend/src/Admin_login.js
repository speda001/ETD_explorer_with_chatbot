import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Validation from './LoginValidation';
import axios from 'axios';
import Cookies from 'js-cookie'; 

function Admin_login() {
const token = Cookies.get('token');
  const [values, setValues] = useState({
    email: '',
    password: ''
  });
  const navigate = useNavigate();
  axios.defaults.withCredentials = true;
  const [errors, setErrors] = useState({});
  const [backendError, setBackendError] = useState([]);
  
  const [alertMessage, setAlertMessage] = useState('');

  const handleInput = (event) => {
    setValues((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setErrors(Validation(values));
    if (errors.email === '' && errors.password === '') {
      axios.post('http://localhost:8081/adminlogin', values)
        .then((res) => {
          if (res.data.errors) {
            setBackendError(res.data.errors);
          } else {
            setBackendError([]);
            if (res.data === 'Success') {

              Cookies.set('token', res.headers['x-auth-token']);
              if (token) {
                console.log('Token found:', token);

              } else {
                console.log('Token not found');
              
              }
              navigate('/admin');
            } else {
              alert('No record existed');
            }
          }
        })
        .catch((err) => {
            console.log(err);
            navigate('/admin');
        });
    }
  };

  return (
    <div className='d-flex justify-content-center align-items-center bg-secondary vh-100'>
      <div className='bg-white p-3 rounded w-25'>
        <h2>Admin Login</h2>
        {backendError ? (
          backendError.map((e) => <p className='text-danger'>{e.msg}</p>)
        ) : (
          <span></span>
        )}
        <form action='' onSubmit={handleSubmit}>
          <div className='mb-3'>
            <label htmlFor='email'><strong>Email</strong></label>
            <input
              type='email'
              placeholder='Enter email'
              name='email'
              onChange={handleInput}
              className='form-control rounded'
            />
            {errors.email && <span className='text-danger'>{errors.email}</span>}
          </div>
          <div className='mb-3'>
            <label htmlFor='password'><strong>Password</strong></label>
            <input
              type='password'
              placeholder='Enter password'
              name='password'
              onChange={handleInput}
              className='form-control rounded'
            />
            {errors.password && <span className='text-danger'>{errors.password}</span>}
          </div>
          <button type='submit' className='btn btn-success w-100 rounded-0'>
            Login
          </button>
          <p></p>
        </form>
        {/* <div className='forgot-password align-items-center'>
          <a href='/forgot_password'>Forgot Password</a>
        </div> */}
      </div>
    </div>
  );
}

export default Admin_login;
