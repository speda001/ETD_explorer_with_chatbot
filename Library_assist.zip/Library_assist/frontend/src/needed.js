import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import DOMPurify from 'dompurify';

function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [totalResults, setTotalResults] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [resultsPerPage] = useState(10);
  const navigate = useNavigate();

  useEffect(() => {
    handleSearch(searchQuery, currentPage);
  }, [searchQuery, currentPage]);

  const handleSearch = (value, page) => {
    var requestOptions = {
      method: 'POST',
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        "index": "wikified_data",
        "searchText": value,
        "page": page,
        "pageSize": resultsPerPage
      }),
      redirect: 'follow'
    };

    fetch("http://localhost:8081/search", requestOptions)
      .then(response => response.json())
      .then(({ hits, total }) => {
        setSearchResults(hits.map(hit => hit._source));
        setTotalResults(total);
      })
      .catch(error => console.log('error', error));
  };

  const highlightSearchTerm = (text, term, charLimit = 150) => {
    if (!text) return "";
    let truncatedText = text.length > charLimit ? text.substring(0, charLimit) + '...' : text;
    if (!term) return truncatedText;
    const re = new RegExp(term, 'gi');
    const sanitizedText = DOMPurify.sanitize(truncatedText);
    return sanitizedText.replace(re, (match) => `<mark>${match}</mark>`);
  };

  const handlePageClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleMoreDetails = (result) => {
    navigate('/details', { state: { data: result } });
  };

  return (
    <div>
      <div className="bg-light">
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <div className="container-fluid">
            <Link className="navbar-brand px-2" to="/home">Home</Link>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link px-2" to="/login">
                    Login
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link px-2" to="/Signup">
                    Sign-up
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link px-2" to="/admin_login">
                    Admin Login
                  </Link>
                </li>
              </ul>
            </div>
            
            <div className="input-group align-items-left w-50 search-container">
              <input
                onChange={(e) => { handleSearch(e.target.value); setSearchQuery(e.target.value) }}
                value={searchQuery}
                type="text"
                className="form-control"
                placeholder="Search..."
              />
              <button onClick={() => handleSearch(searchQuery)} className="btn btn-outline-secondary">Search</button>
            </div>
          </div>
        </nav>
      </div>

      <div className="search-container">
        <div className="input-group">
          <input
            onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
            value={searchQuery}
            type="text"
            className="form-control"
            placeholder="Search..."
          />
          <button onClick={() => handleSearch(searchQuery, 1)} className="btn btn-outline-secondary">Search</button>
        </div>

        <label>Total Results: {totalResults}</label>
        {searchResults.length > 0 && searchResults.map((result, index) => (
          <div key={index} className="search-result">
            <h3 dangerouslySetInnerHTML={{ __html: highlightSearchTerm(result.title, searchQuery) }}></h3>
            <p dangerouslySetInnerHTML={{ __html: highlightSearchTerm(result.abstract, searchQuery) }}></p>
            <p>Author: {result.author}</p>
            <button onClick={() => handleMoreDetails(result)} className="btn btn-primary">More Details</button>
            <br /><br />
          </div>
        ))}

        {totalResults > resultsPerPage && (
          <div className="pagination">
            {Array.from({ length: Math.ceil(totalResults / resultsPerPage) }, (_, index) => (
              <button key={index} onClick={() => handlePageClick(index + 1)} className={`page-button ${currentPage === index + 1 ? 'active' : ''}`}>
                {index + 1}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default Home;
