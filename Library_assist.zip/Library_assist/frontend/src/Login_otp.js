import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

function Login_otp() {
  const [otp, setOtp] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
  
    axios.post('http://localhost:8081/verify-otp', {otp,verificationCode:sessionStorage.getItem('verificationCode'), email:sessionStorage.getItem('email')})
      .then((res) => {
        if (res.data.message === 'Success') {
          sessionStorage.setItem('key', res.data.key);
          navigate('/user_home'); 
        } else {
          alert('Invalid OTP. Please try again.');
        }
      })
      .catch((err) => {
        console.error('Error:', err);
      });
  };

  return (
    <div className="d-flex justify-content-center align-items-center bg-secondary vh-100">
      <div className="bg-white p-3 rounded w-25">
        <h2>Enter OTP</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="otp"><strong>6-Digit OTP</strong></label>
            <input
              type="text"
              placeholder="Enter OTP"
              name="otp"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              className="form-control rounded"
              minLength="6"
              maxLength="6"
              required
            />
          </div>
          <button type="submit" className="btn btn-success w-100 rounded-0">
            <strong>Submit</strong>
          </button>
        </form>
        <p></p>
        <Link
          to="/login"
          className="btn btn-default border w-100 bg-light rounded-0 text-decoration-none">
          Back to Login
        </Link>
      </div>
    </div>
  );
}

export default Login_otp;
