import React from 'react'
import Login from './Login'
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Signup from './Signup'
import Home from './Home'
import Admin from './Admin'
import Create_admin from './Create_admin'
import Admin_changepassword from './Admin_changepassword'
import Admin_details from './Admin_details'
import ForgotPassword from './forgot_password'
import User_homepage from './User_homepage'
import Admin_login from './Admin_login'
import Profile_user from './Profile_user'
import User_authentication from './User_authentication'
import Login_otp from './Login_otp'
import DetailsPage from './DetailsPage';
import Update from './Update';
import Moreinfo from './Moreinfo';
import Reset_pwd from './Reset_pwd';

// import User_home from './User_home'
import User_changepassword from './User_changepassword'

function App() {
  return (
    <BrowserRouter>
    <Routes>
        <Route path='/login' element={<Login />}></Route>
        <Route path='/admin_login' element={<Admin_login/>}></Route>
        <Route path='/create_admin' element={<Create_admin />}></Route>
        <Route path='/admin_details' element={<Admin_details />}></Route>
        <Route path='/admin' element={<Admin />}></Route>
        <Route path='/' element={<Home />}></Route>
        <Route path='/user_profile' element={<Profile_user />}></Route>
        <Route path='/authenticate' element={<User_authentication />}></Route>
        <Route path='/changepassword' element={<User_changepassword />}></Route> 
        <Route path="/details" element={<DetailsPage />} />
        <Route path="/upload" element={<Update />} />
        <Route path="/moreinfo" element={<Moreinfo />} />
        <Route path="/resetpassword" element={<Reset_pwd />} />

        <Route path='/user_home' element={<User_homepage/>}></Route>
        <Route path='/otp' element={<Login_otp />}></Route>
        <Route path='/signup' element={<Signup />}></Route>
        <Route path='/forgot_password' element={<ForgotPassword />}></Route>
        <Route path='/admin_changepassword' element={<Admin_changepassword />}></Route>
        
    </Routes>
    </BrowserRouter>
  )
}

export default App