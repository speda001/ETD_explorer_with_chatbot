import React, {useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Validation from './SignupValidation';
import axios from 'axios';

function CreateAdmin() {
  const [values, setValues] = useState({
    first_name: '',
    email: '',
    password: '',
    phone_no: '',
  });

  
  const navigate = useNavigate();
  const [errors, setErrors] = useState({});
  const [alertMessage, setAlertMessage] = useState('');

  const handleInput = (event) => {
    setValues((prev) => ({ ...prev, [event.target.name]: [event.target.value] }));
  };

  const handleLogout = () => {
    navigate('/admin_login');
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setErrors(Validation(values));

    if (
      errors.first_name === '' &&
      errors.email === '' &&
      errors.password === '' &&
      errors.phone_no === ''
    ) {
      axios
        .post('http://localhost:8081/create', values)
        .then((res) => {
          navigate('/admin');
          alert("Registration successful");
          console.log('Success');
        })
        .catch((err) => {
          if (err.response && err.response.status === 400 && err.response.data.error === 'Email already exists') {
            setAlertMessage('Email already exists. Please use a different email.');
          } else {
            console.log(err);
          }
        });
    }
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light p-3">
              <div className="container-fluid">
                <button className="btn btn-outline-secondary me-2">Back</button>
                <Link className="navbar-brand" to="/admin">
                  Home
                </Link>
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarNav"
                  aria-controls="navbarNav"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                  <ul className="navbar-nav">
                    <li className="nav-item">
                      <Link to="/create_admin" className="nav-link btn btn-outline-success mx-2">
                        Add Admin
                      </Link>
                    </li>
                    <li className="nav-item">
                      <Link to="/admin_details" className="nav-link btn btn-outline-info">
                        Admin Details
                      </Link>
                    </li>
                    <li className="nav-item">
                      <Link
                        className="nav-link  btn btn-outline-secondary"
                        to="/admin_changepassword"
                      >
                        Change Password
                      </Link>
                    </li>
                  </ul>
                </div>
                <button
                  className="btn btn-outline-danger"
                  onClick={handleLogout}>
                  Logout
                </button>
              </div>
            </nav>
      <div className="d-flex justify-content-center align-items-center bg-secondary vh-100">
      <div className="bg-white p-3 rounded w-25">
        <h2>Add Admin-User</h2>
        {alertMessage && (
          <div className="alert alert-danger" role="alert">
            {alertMessage}
          </div>
        )}
        <form action="" onSubmit={handleSubmit}>
                <div className='mb-3'>
                <label htmlFor="first_name"><strong>Name</strong></label>
                <input type="text" placeholder="Enter First Name" name="first_name"
                onChange={handleInput} className='form-control rounded'/>
                {errors.first_name && <span className="text-danger">{errors.first_name}</span>}
            </div>
            <div className='mb-3'>
                <label htmlFor="phone_no"><strong>Phone Number</strong></label>
                <input type="integer" placeholder="Enter Phone Number" name='phone_no'
                onChange={handleInput} className='form-control rounded'/>
                {errors.phone_no && <span className="text-danger">{errors.phone_no}</span>}
            </div>
            <div className='mb-3'>
                <label htmlFor="email"><strong>Email</strong></label>
                <input type="email" placeholder="Enter email" name='email'
                onChange={handleInput} className='form-control rounded'/>
                {errors.email && <span className="text-danger">{errors.email}</span>}
            </div>
            <div className='mb-3'>
                <label htmlFor="password"><strong>Password</strong></label>
                <input type="password" placeholder="Enter password" name='password'
                onChange={handleInput} className='form-control rounded'/>
                {errors.password && <span className="text-danger">{errors.password}</span>}
            </div>
            <button type='submit' className='btn btn-success w-100 rounded-0'><strong>Submit</strong></button>
            <p></p>
        </form>
      </div>
    </div>
    </div>
    
  );
}

export default CreateAdmin;
