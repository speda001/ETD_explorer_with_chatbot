import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

function Admin() {
  const [data, setData] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('http://localhost:8081/user_details')
      .then(res => setData(res.data))
      .catch(err => console.log(err));
  }, []);

  const handleLogout = () => {
    navigate('/admin_login');
  };

  const pendingData = data.filter((item) => item.auth_status === 0);
  const approvedData = data.filter((item) => item.auth_status === 1);

  const handleApprove = (email) => {
    if(true) {
      
      axios.put(`http://localhost:8081/approve/${encodeURIComponent(email)}`)
        .then(() => {
          axios.get('http://localhost:8081/user_details')
            .then(res => setData(res.data))
            .catch(err => console.log(err));
        })
        .catch(err => console.log(err));
    } else {
      alert('User approved');
    }
  };

  return (
    <div style={{ height: '100vh' }}>
      {/* Navigation */}
      <nav className="navbar navbar-expand-lg navbar-light bg-light p-3">
        {/* Navigation Content */}
        <div className="container-fluid">
          <button className="btn btn-outline-secondary me-2" onClick={() => navigate(-1)}>Back</button>
          <Link className="navbar-brand" to="/admin">Home</Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link to="/create_admin" className="nav-link btn btn-outline-success mx-2">
                  Add Admin
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/admin_details" className="nav-link btn btn-outline-info">
                  Admin Details
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  className="nav-link  btn btn-outline-secondary"
                  to="/admin_changepassword"
                >
                  Change Password
                </Link>
              </li>
            </ul>
          </div>
          <button
            className="btn btn-outline-danger"
            onClick={handleLogout}>
            Logout
          </button>
        </div>
      </nav>

      {/* Content Section */}
      <div className="container mt-4">
        {/* Pending Approvals */}
        <div className="row mb-4">
          <div className="col">
            <h2>Required Approvals</h2>
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Phone</th>
                  <th>Email</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {pendingData.map((user, index) => (
                  <tr key={index}>
                    <td>{user.first_name} {user.last_name}</td>
                    <td>{user.phone_no}</td>
                    <td>{user.email}</td>
                    <td>
                      
                        <button 
                          className="btn btn-primary" 
                          onClick={() => handleApprove(user.email)}
                        >
                          Approve
                        </button>
                      
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Approved Users */}
        <div className="row">
          <div className="col">
            <h3>Approved Users</h3>
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Phone</th>
                  <th>Email</th>
                </tr>
              </thead>
              <tbody>
                {approvedData.map((user, index) => (
                  <tr key={index}>
                    <td>{user.first_name} {user.last_name}</td>
                    <td>{user.phone_no}</td>
                    <td>{user.email}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Admin;
