import React, { useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import DOMPurify from 'dompurify';

function DetailsPage() {
    const [searchQuery, setSearchQuery] = useState("");
    const [searchResults, setSearchResults] = useState([]);
    const [totalResults, setTotalResults] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [resultsPerPage] = useState(10);
    const [isChatOpen, setIsChatOpen] = useState(false);
    const [currentMessage, setCurrentMessage] = useState("");
    const [messages, setMessages] = useState([]);
    const navigate = useNavigate();
    const location = useLocation();
    const handleLogout = () => {
      navigate('/login');
    };
    const { data, query } = location.state || {};

    const goBack = () => {
        navigate(-1);
    };

    const highlightSearchTerm = (text, term) => {
        if (!text || !term) return text;
        const re = new RegExp(term, 'gi');
        const sanitizedText = DOMPurify.sanitize(text);
        return sanitizedText.replace(re, (match) => `<mark>${match}</mark>`);
    };

    const wikifyText = (text, wikifierTermsString) => {
        let result = text;
    
        try {
            // Correctly format the string to JSON
            wikifierTermsString = wikifierTermsString.replaceAll("': '", '": "')
                .replaceAll("', '", '", "')
                .replaceAll("{'", '{"')
                .replaceAll("'}", '"}')
                .replaceAll("': \"", '": "')
                .replaceAll("\", '", '", "');
    
            const wikifierTerms = JSON.parse(wikifierTermsString);
    
            // Replace each term in the text with a hyperlink
            wikifierTerms.forEach(termObj => {
                const { term, url } = termObj;
                const regex = new RegExp(`\\b${term}\\b`, "gi");
                result = result.replace(regex, `<a href="${url}" target="_blank" rel="noopener noreferrer">${term}</a>`);

            });
    
        } catch (error) {
            console.error('Error parsing wikifierTerms:', error);
        }
    
        return <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(result) }} />;
    };

    const handleSearch = async (value) => {
        var requestOptions = {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ "index": "wikified_data", "searchText": value }),
            redirect: 'follow'
        };

        fetch("http://localhost:8081/search", requestOptions)
            .then(response => response.json())
            .then(({ hits, total }) => {
                setSearchResults(hits.map(hit => hit._source));
                setTotalResults(total);
                setCurrentPage(1);
            })
            .catch(error => console.log('error', error));
    };

    const handleSendMessage = async () => {
        if (currentMessage.trim() === '') return;
    
        const newMessages = [...messages, { role: 'user', content: currentMessage }];
        setMessages(newMessages);
        setCurrentMessage("");
    
        const requestBody = {
            message: currentMessage,
            abstract: data.abstract, // Assuming 'data' contains the abstract
            title: data.title,
            year: data.year, 
            advisor: data.advisor     // Assuming 'data' contains the title
        };
    
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody)
        };
        
        fetch("http://localhost:8081/respondToQuery", requestOptions)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                setMessages([...newMessages, { role: 'ai', content: data.model_response }]);
            })
            .catch(error => console.error('Error in sending message:', error));        
    };
    

    return (
        <div>
            <div className="bg-light">
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <div className="container-fluid">
            <Link className="navbar-brand px-2" to="/user_home">
              Home
            </Link>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link px-2" to="/user_profile">
                    Profile
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link px-2" to="/changepassword">
                    Change Password
                  </Link>
                </li>
              </ul>
            </div>
            
            <div className="input-group align-items-left w-50 search-container">
              <input
                onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                value={searchQuery}
                type="text"
                className="form-control"
                placeholder="Search..."
              />
              <button onClick={() => handleSearch(searchQuery, 1)} className="btn btn-outline-secondary">Search</button>
            </div>
            <button
                  className="btn btn-outline-danger p-2"
                  onClick={handleLogout}>
                  Logout
                </button>
          </div>
        </nav>
            </div>

            <div>
                <h2>Details</h2>
                <label><strong>Download Link</strong></label>
                {data.pdf ? <a href={data.pdf} target="_blank" rel="noopener noreferrer">Preview/Download</a> : <p>No Preview or Download available</p>}
                <label><strong>Title</strong></label>
                <p dangerouslySetInnerHTML={{ __html: highlightSearchTerm(data.title, searchQuery) }}></p>
                <label><strong>Advisor</strong></label>
                {data.advisor ? <p dangerouslySetInnerHTML={{ __html: highlightSearchTerm(data.advisor, searchQuery) }}></p> : <p>Advisor Details Not Available</p>}
                <label><strong>Abstract</strong></label>
                {data.abstract ? wikifyText(data.abstract, data.wikified_terms) : <p>Abstract Not Available in data</p>}
                <label><strong>Year: </strong></label>
                <p>{data.year}</p>
                <label><strong>Degree:</strong></label>
                <p> {data.degree}</p>
                <label><strong>Author:</strong></label>
                <p dangerouslySetInnerHTML={{ __html: highlightSearchTerm(data.author, searchQuery) }}></p>
                <label><strong>University:</strong></label>
                <p dangerouslySetInnerHTML={{ __html: highlightSearchTerm(data.university, searchQuery) }}></p>
                <label><strong>Program:</strong></label>
                <p dangerouslySetInnerHTML={{ __html: highlightSearchTerm(data.program, searchQuery) }}></p>
                {/* <label>Wikified Terms:</label>
                <p dangerouslySetInnerHTML={{ __html: highlightSearchTerm(data.wikified_terms, searchQuery) }}></p> */}

            </div>

            {/* Chat button */}
            <button onClick={() => setIsChatOpen(!isChatOpen)} style={{ position: 'fixed', bottom: '20px', right: '20px', zIndex: 1000 }}>
                Chat
            </button>

            {/* Chat window */}
            {isChatOpen && (
                <div style={{ position: 'fixed', bottom: '60px', right: '20px', width: '300px', height: '400px', border: '1px solid black', padding: '10px', backgroundColor: 'white', zIndex: 1000, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                    <h3>Chat</h3>
                    <button onClick={() => setIsChatOpen(false)} style={{ position: 'absolute', top: '4px', right: '4px' }}>X</button>
                    <div style={{ flexGrow: 1, overflowY: 'auto', maxHeight: '300px' }}>
                        {messages.map((msg, index) => (
                            <div key={index}><b>{msg.role}:</b> {msg.content}</div>
                        ))}
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center' }}>
                        <input 
                            type="text" 
                            value={currentMessage} 
                            onChange={(e) => setCurrentMessage(e.target.value)}
                            style={{ flexGrow: 1, marginRight: '5px' }} 
                        />
                        <button onClick={handleSendMessage} style={{ width: '25%' }}>Send</button>
                    </div>
                </div>
            )}
        </div>
    );
}

export default DetailsPage;
