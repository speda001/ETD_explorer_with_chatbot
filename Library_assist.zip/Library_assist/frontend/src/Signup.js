import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Validation from './SignupValidation';
import axios from 'axios';

function Signup() {
  const [values, setValues] = useState({
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    phone_no: '',
  });
  const navigate = useNavigate();
  const [errors, setErrors] = useState({});
  const [alertMessage, setAlertMessage] = useState('');

  const handleInput = (event) => {
    setValues((prev) => ({ ...prev, [event.target.name]: [event.target.value] }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setErrors(Validation(values));

    if (
      errors.first_name === '' &&
      errors.last_name === '' &&
      errors.email === '' &&
      errors.password === '' &&
      errors.phone_no === ''
    ) {
      axios
        .post('http://localhost:8081/signup', values)
        .then((res) => {
          navigate('/login');
          alert("Registration successful");
          console.log('Success');
        })
        .catch((err) => {
          if (err.response && err.response.status === 400 && err.response.data.error === 'Email already exists') {
            setAlertMessage('Email already exists. Please use a different email.');
          } else {
            console.log(err);
          }
        });
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center bg-secondary vh-100">
      <div className="bg-white p-3 rounded w-25">
        <h2>Sign-Up</h2>
        {alertMessage && (
          <div className="alert alert-danger" role="alert">
            {alertMessage}
          </div>
        )}
        <form action="" onSubmit={handleSubmit}>
                <div className='mb-3'>
                <label htmlFor="first_name"><strong>First Name</strong></label>
                <input type="text" placeholder="Enter First Name" name="first_name"
                onChange={handleInput} className='form-control rounded'/>
                {errors.first_name && <span className="text-danger">{errors.first_name}</span>}
            </div>
            <div className='mb-3'>
                <label htmlFor="last_name"><strong>Last Name</strong></label>
                <input type="text" placeholder="Enter Last Name" name='last_name'
                onChange={handleInput} className='form-control rounded'/>
                {errors.last_name && <span className="text-danger">{errors.last_name}</span>}
            </div>
            <div className='mb-3'>
                <label htmlFor="phone_no"><strong>Phone Number</strong></label>
                <input type="integer" placeholder="Enter Phone Number" name='phone_no'
                onChange={handleInput} className='form-control rounded'/>
                {errors.phone_no && <span className="text-danger">{errors.phone_no}</span>}
            </div>
            <div className='mb-3'>
                <label htmlFor="email"><strong>Email</strong></label>
                <input type="email" placeholder="Enter email" name='email'
                onChange={handleInput} className='form-control rounded'/>
                {errors.email && <span className="text-danger">{errors.email}</span>}
            </div>
            <div className='mb-3'>
                <label htmlFor="password"><strong>Password</strong></label>
                <input type="password" placeholder="Enter password" name='password'
                onChange={handleInput} className='form-control rounded'/>
                {errors.password && <span className="text-danger">{errors.password}</span>}
            </div>
            <button type='submit' className='btn btn-success w-100 rounded-0'><strong>Sign up</strong></button>
            <p></p>
            <Link to="/login" className='btn btn-default border w-100 bg-light rounded-0 text-decoration-none'>Login</Link>
        </form>
      </div>
    </div>
  );
}

export default Signup;
