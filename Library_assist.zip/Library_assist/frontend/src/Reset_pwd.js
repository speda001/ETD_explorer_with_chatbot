import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

function Reset_pwd() {
  const [email, setEmail] = useState(''); 

  const [password, setPassword] = useState('');
  const [npassword, setnPassword] = useState('');

  const navigate = useNavigate();
  const handleLogout = () => {
    navigate('/login');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    axios
      .post('http://localhost:8081/uchangepwd', { email, password, npassword })
      .then((res) => {
        if (res.status === 200) {
          console.log('Password Rest successfully');
        
          navigate('/login');
          alert('Password Reset successfully');
        } else {
          console.error('Failed to update password');
        }
      })
      .catch((err) => {
        console.error('Error updating password:', err);
        alert('password did not matched');
      });
  };

  return (
    <div>
      
      <div className='d-flex justify-content-center align-items-center bg-primary vh-100'>
        <div className='bg-white p-5 rounded w-25'>
          <h3>Change Password</h3>
          <form onSubmit={handleSubmit}>
            <div className='mb-2'>
              <label>Confirm your Email</label>
              <input
                type='email'
                name='email'
                placeholder='Enter your email'
                className='form-control'
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className='mb-2'>
              <label>Current Password</label>
              <input
                type='password'
                name='password'
                placeholder='Enter Your current password'
                className='form-control'
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div className='mb-2'>
              <label>New Password</label>
              <input
                type='password'
                name='npassword'
                placeholder='Enter New Password'
                className='form-control'
                onChange={(e) => setnPassword(e.target.value)}
              />
            </div>
            <button className='btn btn-success'>Submit</button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Reset_pwd
